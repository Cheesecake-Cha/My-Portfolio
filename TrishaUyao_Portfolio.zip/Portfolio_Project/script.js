// Dark Mode Toggle
const darkModeToggle = document.getElementById("darkModeToggle");
darkModeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
});

// Dynamically Add Projects
const projects = [
    { title: "Project 1", description: "Description for project 1" },
    { title: "Project 2", description: "Description for project 2" }
];

const projectsContainer = document.getElementById("projectsContainer");
projects.forEach(project => {
    const projectElement = document.createElement("div");
    projectElement.innerHTML = `<h3>${project.title}</h3><p>${project.description}</p>`;
    projectsContainer.appendChild(projectElement);
});

// Dynamically Add Skills
const skills = ["HTML", "CSS", "JavaScript", "React"];
const skillsList = document.getElementById("skillsList");

skills.forEach(skill => {
    const skillItem = document.createElement("li");
    skillItem.textContent = skill;
    skillsList.appendChild(skillItem);
});

// Contact Form Validation
const contactForm = document.getElementById("contactForm");
contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields.");
    } else {
        alert("Message sent successfully!");
        contactForm.reset();
    }
});

// Display Current Year
document.getElementById("currentYear").textContent = new Date().getFullYear();